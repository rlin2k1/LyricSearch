Problems: None

Citations:
  1) http://initd.org/psycopg/docs/usage.html
     (Parameterized queries in Psycopg2)